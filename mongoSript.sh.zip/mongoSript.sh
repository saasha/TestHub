#!/bin/bash

# *************************************
## Purpose: To create mongodumps of specified databases, and add the zipped folders to the git repository
## Uses "SSH for Git" to be able to interact with Git
## Needs "hub" to be installed to raise a PR. Also, please add personal access token to ~/.config/hub so that username and password does not have to be entered everytime
## 
## author: Saasha Nair
## dated: November 24, 2015
# *************************************

## Variables
BACKUP_BASE_PATH="/home/saasha/inferlytics/TestHub"
TODAYS_DATE=$(date "+%Y%m%d%H%M%S")
BACKUP_PATH=$BACKUP_BASE_PATH/"test_dump"
BRANCH_NAME="test/dbdump1234"
declare -a DB_TO_DUMP_LIST=("test")
## End of variables

# If the folder does not exist, then create the folder
[ ! -d $BACKUP_PATH ] && mkdir -p $BACKUP_PATH || :

# Ensure directory exists before dumping to it
if [ -d "$BACKUP_PATH" ]; then	
	cd $BACKUP_PATH
	pwd
	
	echo "LIST OF FILES"
	ls
	echo "=========="
	for entry in `ls -I "*.sh"`
	do
		echo $entry
	done

	cd $BACKUP_BASE_PATH

	echo "CHECKING BRANCHES"
	git branch
	echo "============="

	# Checkout the test/dbdump branch, incase it does not already exist, create the branch from development
	if [ "`git branch --list $BRANCH_NAME`" ]; then
		echo "$BRANCH_NAME already exists"
		git checkout $BRANCH_NAME
		#git pull origin development
		git pull origin dev
		git push origin $BRANCH_NAME
	else
		echo "Creating branch: $BRANCH_NAME"
		#git checkout development
		#git pull origin development
		git checkout dev
		git pull origin dev
		git checkout -b $BRANCH_NAME
	fi

	pwd

	# Create a dump of all databases mentioned in the list	
	for db_name in "${DB_TO_DUMP_LIST[@]}"
	do
		echo "Dumping DB: $db_name"
		mongodump -d $db_name -o $BACKUP_PATH
		echo "Done dumping DB: $db_name"
	done

	pwd

	# to create individual zips of all files in the directory (ensures that files with .zip extension are not zipped again)
	for entry in `ls -I "*.zip"`
	do
		echo "Zipping file: $entry"
		zip -r $entry.zip $entry
		rm -r $entry
	done

	# add the zip files to the list of git files staged for commit
	
	#for file in *.zip;
	#do
	#	echo "Adding file: $file"
	#	git add $file
	#done	
	

	git add -A

	echo "============= Files added ============="
	git status

	# commit and push changes to git
	git commit -m "Back up of database on $TODAYS_DATE"
	
	echo "CHECKING"
	#git status

	git push -f origin $BRANCH_NAME

	hub pull-request -m "Back up of DB on $TODAYS_DATE" -b dev -h $BRANCH_NAME
fi
